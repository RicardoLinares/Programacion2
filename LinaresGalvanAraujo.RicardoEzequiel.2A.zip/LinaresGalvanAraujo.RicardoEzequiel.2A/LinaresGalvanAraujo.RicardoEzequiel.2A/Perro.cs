﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mascotas
{
    public class Perro : Mascota
    {
        private int _edad;
        private bool _esAlfa;

        public Perro(string nombre, string raza) : this(nombre, raza, 0, false)
        {

        }

        public Perro(string nombre, string raza, int edad, bool esAlfa) : base(nombre, raza)
        {
            this._edad = edad;
            this._esAlfa = esAlfa;
        }

        protected override string Ficha()
        {
            string ficha;
            ficha = base.DatosCompletos();
            if(this._esAlfa)
            {
                ficha += ", alfa de la manada";
            }
            ficha += ", edad " + this._edad;
            return ficha;
        }

        public static bool operator ==(Perro perroA, Perro perroB)
        {
            bool respuesta = false;
            if(perroA._edad == perroB._edad)
            {
                if(perroA.Raza == perroB.Raza)
                {
                    if(perroA.Nombre == perroB.Nombre)
                    {
                        respuesta = true;
                    }
                }
            }
            return respuesta;
        }

        public static bool operator !=(Perro perroA, Perro perroB)
        {
            return !(perroA == perroB);
        }

        public static explicit operator int(Perro perro)
        {
            return perro._edad;
        }

        public override string ToString()
        {
            return this.Ficha();
        }

        public override bool Equals(object obj)
        {
            bool respuesta = false;
            if(obj is Perro)
            {
                respuesta = this == (Perro)obj;
            }
            return respuesta;
        }
    }
}
