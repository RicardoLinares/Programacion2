﻿using System.Collections.Generic;
using System;
namespace Mascotas
{
    public class Grupo
    {
        private List<Mascota> _manada;
        private string _nombre;
        private static ETipoManada _tipo;

        public static ETipoManada Tipo
        {
            set
            {
                Grupo._tipo = value;
            }
        }
        static Grupo()
        {
            Grupo._tipo = ETipoManada.Unica;
        }
        private Grupo()
        {
            this._manada = new List<Mascota>();
        }

        public Grupo(string nombre, ETipoManada eTipo) : this()
        {
            this._nombre = nombre;
            Grupo._tipo = eTipo;
        }

        public Grupo(string nombre) : this(nombre,ETipoManada.Unica)
        {

        }

        public static bool operator ==(Grupo grupo, Mascota mascota)
        {
            return grupo._manada.Contains(mascota);
        }
        public static bool operator !=(Grupo grupo, Mascota mascota)
        {
            return !(grupo == mascota);
        }

        public static Grupo operator +(Grupo grupo, Mascota mascota)
        {
            if(grupo != mascota)
            {
                grupo._manada.Add(mascota);
            }
            else
            {
                Console.WriteLine("ya esta el {0} en la manada", mascota.ToString());
            }
            return grupo;
        }
        public static Grupo operator -(Grupo grupo, Mascota mascota)
        {
            if (grupo == mascota)
            {
                grupo._manada.Remove(mascota);
            }
            else
            {
                Console.WriteLine("no esta el {0} en la manada", mascota.ToString());
            }
            return grupo;
        }

        public static implicit operator string(Grupo grupo)
        {
            string fichaGrupal;

            fichaGrupal = "Grupo: " + grupo._nombre + " - Tipo: " + Grupo._tipo.ToString() + "\n";
            fichaGrupal += "Intengrantes <" + grupo._manada.Count + ">:\n";
            foreach(Mascota mascota in grupo._manada)
            {
                fichaGrupal += mascota.ToString() + "\n";
            }
            return fichaGrupal;
        }
    }
}
