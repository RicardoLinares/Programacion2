﻿namespace Mascotas
{
    public enum ETipoManada
    {
        Unica,
        Mixta
    }
}