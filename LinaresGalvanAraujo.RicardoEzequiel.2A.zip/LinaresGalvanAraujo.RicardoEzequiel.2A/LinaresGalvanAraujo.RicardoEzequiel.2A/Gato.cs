﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mascotas
{
    public class Gato : Mascota
    {
        public Gato(string nombre, string raza) : base(nombre, raza)
        {

        }

        protected override string Ficha()
        {
            return base.DatosCompletos();
        }

        public static bool operator ==(Gato gatoA, Gato gatoB)
        {
            bool respuesta = false;
            if(gatoA.Nombre == gatoB.Nombre)
            {
                if(gatoA.Raza == gatoB.Raza)
                {
                    respuesta = true;
                }
            }
            return respuesta;
        }
        public static bool operator !=(Gato gatoA, Gato gatoB)
        {
            return !(gatoA == gatoB);
        }

        public override string ToString()
        {
            return this.Ficha();
        }

        public override bool Equals(object obj)
        {
            bool respuesta = false;
            if(obj is Gato)
            {
                respuesta = this == (Gato)obj;
            }
            return respuesta;
        }
    }
}
